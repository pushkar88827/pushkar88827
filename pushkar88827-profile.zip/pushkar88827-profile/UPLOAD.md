# Upload steps

1. Open your profile repository: https://github.com/pushkar88827/pushkar88827
2. Replace its root `README.md` with this `README.md`.
3. Upload the complete `assets/` folder, keeping filenames and paths unchanged.
4. Commit, then check the profile on desktop and mobile.

The SVGs are self-contained. The supplied profile photo is embedded in the hero and connect artwork. The statistics in `id-dashboard.svg` were captured from the public profile on Oct 12, 2026 and will become stale; update or remove them as needed.
